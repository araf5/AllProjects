package sampleapp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EdgeCaseTests {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        try {
            driver.get("https://magento.softwaretestingboard.com/");
            driver.manage().window().maximize();

            // Testing Edge Cases for Login Inputs
            WebElement loginLink = driver.findElement(By.linkText("Sign In"));
            loginLink.click();
            Thread.sleep(2000);

            WebElement username = driver.findElement(By.id("email"));
            WebElement password = driver.findElement(By.id("pass"));
            WebElement loginButton = driver.findElement(By.id("send2"));

            // Min Length Test
            username.sendKeys("a");
            password.sendKeys("a");
            loginButton.click();
            Thread.sleep(2000);
            System.out.println("Minimum length input tested!");

            // Max Length Test
            username.clear();
            password.clear();
            username.sendKeys("a".repeat(300));
            password.sendKeys("b".repeat(300));
            loginButton.click();
            Thread.sleep(2000);
            System.out.println("Maximum length input tested!");

            // Unexpected Character Test
            username.clear();
            password.clear();
            username.sendKeys("<script>alert('Test');</script>");
            password.sendKeys("<script>alert('Test');</script>");
            loginButton.click();
            Thread.sleep(2000);
            System.out.println("Unexpected character input tested!");
        } catch (Exception e) {
            System.out.println("Error in Edge Case Tests: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }
}
