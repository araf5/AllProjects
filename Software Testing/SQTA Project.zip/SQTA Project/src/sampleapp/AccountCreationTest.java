package sampleapp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AccountCreationTest {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Drivers\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        try {
            // Step 1: Navigate to Magento Test Site and Create an Account
            driver.get("https://magento.softwaretestingboard.com/");
            driver.manage().window().maximize();
            Thread.sleep(2000);

            WebElement createAccountLink = driver.findElement(By.cssSelector("a[href*='customer/account/create/']"));
            createAccountLink.click();
            Thread.sleep(2000);

            WebElement firstName = driver.findElement(By.id("firstname"));
            WebElement lastName = driver.findElement(By.id("lastname"));
            WebElement email = driver.findElement(By.id("email_address"));
            WebElement password = driver.findElement(By.id("password"));
            WebElement confirmPassword = driver.findElement(By.id("password-confirmation"));

            firstName.sendKeys("Test");
            lastName.sendKeys("User");
            String uniqueEmail = "testuser" + System.currentTimeMillis() + "@example.com";
            email.sendKeys(uniqueEmail);
            password.sendKeys("TestPassword123!");
            confirmPassword.sendKeys("TestPassword123!");

            WebElement createAccountButton = driver.findElement(By.cssSelector("button[title='Create an Account']"));
            createAccountButton.click();
            Thread.sleep(5000);

            System.out.println("Account Creation Successful!");

            // Step 2: Login to the Created Account
            driver.get("https://magento.softwaretestingboard.com/customer/account/login/");
            WebElement emailField = driver.findElement(By.id("email"));
            WebElement passwordField = driver.findElement(By.id("pass"));
            WebElement loginButton = driver.findElement(By.id("send2"));

            emailField.sendKeys(uniqueEmail);
            passwordField.sendKeys("TestPassword123!");
            loginButton.click();
            Thread.sleep(5000);

            System.out.println("Login with Created Account Successful!");

            // Step 3: Add Product to Cart
            WebElement searchBox = driver.findElement(By.id("search"));
            searchBox.sendKeys("Jacket");
            searchBox.submit();
            Thread.sleep(5000);

            WebElement firstProduct = driver.findElement(By.cssSelector(".product-item-link"));
            firstProduct.click();
            Thread.sleep(3000);

            WebElement addToCartButton = driver.findElement(By.id("product-addtocart-button"));
            addToCartButton.click();
            Thread.sleep(3000);

            System.out.println("Product Added to Cart Successfully!");

            // Step 4: Proceed to Checkout
            WebElement cartIcon = driver.findElement(By.cssSelector(".showcart"));
            cartIcon.click();
            Thread.sleep(2000);

            WebElement proceedToCheckoutButton = driver.findElement(By.id("top-cart-btn-checkout"));
            proceedToCheckoutButton.click();
            Thread.sleep(5000);

            System.out.println("Checkout Process Started!");

            // Step 5: Place the Order
            WebElement placeOrderButton = driver.findElement(By.cssSelector(".place-order"));
            placeOrderButton.click();
            Thread.sleep(5000);

            System.out.println("Order Placed Successfully!");

        } catch (Exception e) {
            System.out.println("Account Creation Test Error: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }
}
