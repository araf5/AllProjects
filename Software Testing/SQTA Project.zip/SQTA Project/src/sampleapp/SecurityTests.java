package sampleapp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SecurityTests {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        try {
            driver.get("https://magento.softwaretestingboard.com/");
            driver.manage().window().maximize();

            WebElement loginLink = driver.findElement(By.linkText("Sign In"));
            loginLink.click();
            Thread.sleep(2000);

            WebElement username = driver.findElement(By.id("email"));
            WebElement password = driver.findElement(By.id("pass"));
            WebElement loginButton = driver.findElement(By.id("send2"));

            username.sendKeys("' OR '1'='1");
            password.sendKeys("' OR '1'='1");
            loginButton.click();
            Thread.sleep(3000);
            System.out.println("SQL Injection tested!");

        } catch (Exception e) {
            System.out.println("Error in Security Tests: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }
}
