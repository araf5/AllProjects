package sampleapp;

public class practice {
    public static void main(String[] args) {
        System.out.println("Starting Selenium Tests...");

        // Execute each test class sequentially
        runTest("Functional Tests", FunctionalTests::main, args);
        runTest("Input Validation Tests", InputValidationTests::main, args);
        runTest("Edge Case Tests", EdgeCaseTests::main, args);
        runTest("Security Tests", SecurityTests::main, args);
        runTest("Account Creation Test", AccountCreationTest::main, args);
        runTest("SSL Test", SSLTest::main, args);



        System.out.println("\nAll tests completed successfully!");
    }

    /**
     * Helper method to execute a test class and handle exceptions.
     *
     * @param testName The name of the test being executed.
     * @param testClass A reference to the main method of the test class.
     * @param args Arguments passed to the test class (if any).
     */
    private static void runTest(String testName, RunnableTest testClass, String[] args) {
        System.out.println("\n--- Starting " + testName + " ---");
        try {
            testClass.run(args);
            System.out.println("--- " + testName + " Completed Successfully ---");
        } catch (Exception e) {
            System.err.println("Error during " + testName + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Functional interface to represent a test class's main method.
     */
    @FunctionalInterface
    interface RunnableTest {
        void run(String[] args);
    }
}
