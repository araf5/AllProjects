package sampleapp;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class InputValidationTests {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        try {
            driver.get("https://magento.softwaretestingboard.com/");
            driver.manage().window().maximize();

            // Testing Input Validations
            WebElement loginLink = driver.findElement(By.linkText("Sign In"));
            loginLink.click();
            Thread.sleep(2000);

            WebElement username = driver.findElement(By.id("email"));
            WebElement password = driver.findElement(By.id("pass"));
            WebElement loginButton = driver.findElement(By.id("send2"));

            // Special Character Input Test
            username.sendKeys("!@#$%^&*()");
            password.sendKeys("!@#$%^&*()");
            loginButton.click();
            Thread.sleep(2000);
            System.out.println("Special character input tested!");

            // Long Input Test
            username.clear();
            password.clear();
            username.sendKeys("a".repeat(500));
            password.sendKeys("b".repeat(500));
            loginButton.click();
            Thread.sleep(2000);
            System.out.println("Excessively long input tested!");
        } catch (Exception e) {
            System.out.println("Error in Input Validation Tests: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }
}
